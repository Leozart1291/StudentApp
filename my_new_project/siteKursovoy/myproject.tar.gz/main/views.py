from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.models import User
from .models import CourseCard, Profession
from .models import CourseInfo
from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import CourseCard, UserCourse, LessonProgress, Lesson
from .models import CourseCard, Profession


def index(request):
    profession_id = request.GET.get('profession')  # берем id из фильтра
    professions = Profession.objects.all()

    if profession_id:
        courses = CourseCard.objects.filter(profession_id=profession_id)
    else:
        courses = CourseCard.objects.all()

    return render(request, 'main/index.html', {
        'courses': courses,
        'professions': professions,
        'selected_profession': profession_id
    })

def Kursy(request):
    return render(request, 'main/Kursy.html')

def Login(request):
    return render(request, 'main/Login.html')

@login_required
def Profile(request):
    user_courses = UserCourse.objects.filter(user=request.user)
    return render(request, 'main/Profile.html', {'user_courses': user_courses})

def Profile_edit(request):
    return render(request, 'main/Profile_edit.html')

def Register(request):
    return render(request, 'main/Register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')  # заменишь на нужную страницу
        else:
            messages.error(request, 'Неверный логин или пароль')

    return render(request, 'main/Login.html')



from django.template.loader import render_to_string
from django.http import HttpResponse

def filter_courses(request):
    prof_id = request.GET.get('profession')
    if prof_id:
        courses = CourseCard.objects.filter(profession_id=prof_id)
    else:
        courses = CourseCard.objects.all()[:10]

    html = render_to_string('partials/courses_grid.html', {'courses': courses})
    return HttpResponse(html)





def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm-password')
        role = request.POST.get('role')

        if password != confirm_password:
            messages.error(request, "Пароли не совпадают!")
            return render(request, 'main/Register.html')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Пользователь с таким именем уже существует!")
            return render(request, 'main/Register.html')

        user = User.objects.create_user(username=username, email=email, password=password)
        user.first_name = role  # например, можно временно хранить пол в first_name
        user.save()

        messages.success(request, "Регистрация прошла успешно! Теперь войдите в аккаунт.")
        return redirect('Login')

    return render(request, 'main/Register.html')







def courses_page(request):
    profession_id = request.GET.get('profession')  # берем id из фильтра
    professions = Profession.objects.all()

    if profession_id:
        courses = CourseCard.objects.filter(profession_id=profession_id)
    else:
        courses = CourseCard.objects.all()

    return render(request, 'main/courses.html', {
        'no_scroll': True,
        'courses': courses,
        'professions': professions,
        'selected_profession': profession_id
    })







def coursesInf(request):
    coursesinf = CourseInfo.objects.all()

    return render(request, 'main/coursesInfo.html', {'coursesinf': coursesinf})








def course_detail(request, course_id):
    course = get_object_or_404(CourseCard, id=course_id)
    return render(request, 'main/course_detail.html', {'course': course})

'''def course_detail(request, id):
    course = get_object_or_404(CourseCard, id=id)
    return render(request, 'main/course_detail.html', {'course': course})'''




@login_required
def lesson_detail(request, course_id, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id, module__course_id=course_id)
    course = lesson.module.course

    # Проверяем, добавил ли пользователь этот курс себе
    user_course, _ = UserCourse.objects.get_or_create(user=request.user, course=course)

    # Проверяем прогресс по уроку
    lesson_progress, _ = LessonProgress.objects.get_or_create(user_course=user_course, lesson=lesson)

    # Формируем embed ссылку для видео
    embed_url = get_embed_url(lesson.video_url)

    # Возвращаем контекст для шаблона
    return render(request, 'main/lesson_detail.html', {
        'lesson': lesson,
        'course': course,
        'lesson_progress': lesson_progress,
        'embed_url': embed_url,
    })



@login_required
def complete_lesson(request, course_id, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id)
    course = get_object_or_404(CourseCard, id=course_id)
    user_course = UserCourse.objects.get(user=request.user, course=course)

    progress, created = LessonProgress.objects.get_or_create(
        user_course=user_course,
        lesson=lesson
    )
    progress.is_completed = True
    progress.completed_at = timezone.now()
    progress.save()

    # обновляем прогресс
    total_lessons = Lesson.objects.filter(module__course=course).count()
    completed_lessons = LessonProgress.objects.filter(user_course=user_course, is_completed=True).count()
    user_course.progress = (completed_lessons / total_lessons) * 100
    user_course.save()

    # переход к следующему уроку
    next_lesson = Lesson.objects.filter(
        module=lesson.module,
        order__gt=lesson.order
    ).order_by('order').first()

    if next_lesson:
        return redirect('lesson_detail', course_id=course.id, lesson_id=next_lesson.id)
    return redirect('course_learn', course_id=course.id)




@login_required
def add_to_my_courses(request, course_id):
    course = get_object_or_404(CourseCard, id=course_id)
    UserCourse.objects.get_or_create(user=request.user, course=course)
    return redirect('Profile')


'''@login_required
def my_courses(request):
    user_courses = UserCourse.objects.filter(user=request.user)
    return render(request, 'main/Profile.html', {'user_courses': user_courses})'''


@login_required
def course_learn(request, course_id):
    course = get_object_or_404(CourseCard, id=course_id)
    return render(request, 'main/course_learn.html', {'course': course})





def get_embed_url(video_url):
    """Преобразует любую ссылку YouTube в nocookie embed URL"""
    video_url = video_url.strip()
    video_id = ''

    if 'watch?v=' in video_url:
        video_id = video_url.split('watch?v=')[1].split('&')[0]
    elif 'youtu.be/' in video_url:
        video_id = video_url.split('youtu.be/')[1].split('?')[0]

    if video_id:
        return f'https://www.youtube-nocookie.com/embed/{video_id}'
    return ''



from django.shortcuts import render, get_object_or_404
from .models import Module, LessonTest, TestResult

@login_required
def module_detail(request, module_id):
    module = get_object_or_404(Module, id=module_id)
    course = module.course

    # Находим предыдущий модуль
    previous_module = course.modules.filter(order__lt=module.order).last()

    if previous_module:
        previous_lessons = previous_module.lessons.all()
        user_course = request.user.user_courses.get(course=course)

        all_completed = all(
            lesson.lessonprogress_set.filter(user_course=user_course, is_completed=True).exists()
            for lesson in previous_lessons
        )

        if not all_completed:
            return render(request, 'main/locked_module.html', {
                'previous_module': previous_module
            })





from django.shortcuts import render, get_object_or_404, redirect
from .models import Lesson, LessonTest, Question, Answer, TestResult, LessonProgress

def take_test(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id)
    test = getattr(lesson, 'test', None)

    if not test:
        return render(request, 'no_test.html', {'lesson': lesson})

    questions = test.questions.prefetch_related('answers')

    if request.method == 'POST':
        correct_count = 0
        total = questions.count()

        for q in questions:
            selected_id = request.POST.get(f'question_{q.id}')
            if selected_id:
                answer = Answer.objects.get(id=selected_id)
                if answer.is_correct:
                    correct_count += 1

        score = (correct_count / total) * 100 if total > 0 else 0
        passed = score >= 70  # например, минимум 70% для прохождения

        TestResult.objects.update_or_create(
            user=request.user,
            test=test,
            defaults={'score': score, 'passed': passed}
        )

        # Если тест пройден — отмечаем урок как завершённый
        user_course = request.user.user_courses.get(course=lesson.module.course)
        LessonProgress.objects.update_or_create(
            user_course=user_course,
            lesson=lesson,
            defaults={'is_completed': passed}
        )

        return render(request, 'main/test_result.html', {
            'lesson': lesson,
            'score': score,
            'passed': passed
        })

    return render(request, 'main/take_test.html', {
        'lesson': lesson,
        'test': test,
        'questions': questions
    })



@login_required
def course_learn(request, course_id):
    course = get_object_or_404(CourseCard, id=course_id)
    modules = course.modules.all().order_by('order')

    # Пройденные тесты пользователя
    user_tests = TestResult.objects.filter(user=request.user, passed=True)
    passed_tests = {result.test.id for result in user_tests}

    # Разблокированные модули
    passed_modules = set()
    for i, module in enumerate(modules):
        if i == 0:
            # Первый модуль всегда доступен
            passed_modules.add(module.id)
        else:
            prev_module = modules[i-1]
            prev_tests = [lesson.test.id for lesson in prev_module.lessons.all() if lesson.test]
            # Модуль доступен, если все тесты предыдущего модуля пройдены
            if all(tid in passed_tests for tid in prev_tests):
                passed_modules.add(module.id)

    context = {
        'course': course,
        'modules': modules,
        'passed_tests': passed_tests,
        'passed_modules': passed_modules,
    }
    return render(request, 'main/course_learn.html', context)