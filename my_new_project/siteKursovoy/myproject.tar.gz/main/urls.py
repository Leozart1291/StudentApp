from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

urlpatterns = [
                  path('', views.index, name='index'),
                  path('filter_courses/', views.filter_courses, name='filter_courses'),
                  path('Kursy/', views.Kursy, name='Kursy'),
                  path('Login/', views.Login, name='Login'),
                  path('Profile/', views.Profile, name='Profile'),
                  path('Profile_edit/', views.Profile_edit, name='Profile_edit'),
                  path('Register/', views.Register, name='Register'),
                  path('login/', views.login_view, name='login'),
                  path('register/', views.register_view, name='register'),
                  path('logout/', auth_views.LogoutView.as_view(), name='logout'),

                  path('courses/', views.courses_page, name='courses'),
                  path('courses/<int:course_id>/', views.course_detail, name='course_detail'),

                  # уроки
                  path('course/<int:course_id>/lesson/<int:lesson_id>/', views.lesson_detail, name='lesson_detail'),
                  path('lesson/<int:course_id>/<int:lesson_id>/complete/', views.complete_lesson,
                       name='complete_lesson'),

                  # мои курсы
                  path('courses/<int:course_id>/add/', views.add_to_my_courses, name='add_to_my_courses'),
                  path('my-courses/<int:course_id>/', views.course_learn, name='course_learn'),


                # Модули курса (с проверкой доступа)
                path('module/<int:module_id>/', views.module_detail, name='module_detail'),

                # (опционально) Тест к уроку
                path('lesson/<int:lesson_id>/test/', views.take_test, name='lesson_test'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

