from django.contrib import admin
from .models import (
    Profile, Profession, CourseCard, CourseInfo,
    Module, Lesson, UserCourse, LessonProgress
)

# 📸 Профиль пользователя
@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'gender', 'photo')
    search_fields = ('user__username',)


# 💼 Профессии
@admin.register(Profession)
class ProfessionAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    search_fields = ('name',)


# 📘 Информация о курсе
@admin.register(CourseInfo)
class CourseInfoAdmin(admin.ModelAdmin):
    list_display = ('title',)
    search_fields = ('title',)


# 🎓 Карточки курсов
class ModuleInline(admin.TabularInline):
    model = Module
    extra = 1

@admin.register(CourseCard)
class CourseCardAdmin(admin.ModelAdmin):
    list_display = ('title', 'profession')
    list_filter = ('profession',)
    search_fields = ('title',)
    inlines = [ModuleInline]


# 📚 Модули курсов
class LessonInline(admin.TabularInline):
    model = Lesson
    extra = 1

@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'order')
    list_filter = ('course',)
    search_fields = ('title',)
    inlines = [LessonInline]


# 🧠 Уроки
@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ('title', 'module', 'order')
    list_filter = ('module',)
    search_fields = ('title',)


# 👨‍🎓 Курсы пользователей
@admin.register(UserCourse)
class UserCourseAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'progress', 'started_at')
    list_filter = ('user', 'course')
    search_fields = ('user__username', 'course__title')


# 📈 Прогресс уроков
@admin.register(LessonProgress)
class LessonProgressAdmin(admin.ModelAdmin):
    list_display = ('user_course', 'lesson', 'is_completed', 'completed_at')
    list_filter = ('is_completed', 'lesson')
    search_fields = ('user_course__user__username', 'lesson__title')





# admin.py

from django.contrib import admin
from .models import LessonTest, Question, Answer, TestResult

class AnswerInline(admin.TabularInline):
    model = Answer
    extra = 1
    fields = ('order', 'text', 'is_correct')
    ordering = ('order',)

class QuestionInline(admin.StackedInline):
    model = Question
    extra = 1
    fields = ('order', 'text')
    ordering = ('order',)
    show_change_link = True  # чтобы перейти в отдельную страницу вопроса (если нужно)

@admin.register(LessonTest)
class LessonTestAdmin(admin.ModelAdmin):
    list_display = ('lesson', 'title')
    inlines = [QuestionInline]

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'test')
    inlines = [AnswerInline]
    ordering = ('order',)

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'question', 'is_correct')
    ordering = ('question', 'order')

@admin.register(TestResult)
class TestResultAdmin(admin.ModelAdmin):
    list_display = ('user', 'test', 'score', 'passed', 'completed_at')
    list_filter = ('passed', 'completed_at')
